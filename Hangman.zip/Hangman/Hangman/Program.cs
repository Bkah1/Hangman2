﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hangman
{
    using HangmanSupport;
    class Program
    {
        static void Main(string[] args)
        {
            char[] secret;
            char[] letters;
            char[] mask;
            int winCount = 0;
            int lossCount = 0;
            int misses = 0;

            string guess;

            bool match;

            const int MAX_ALPHABET_LETTERS = 26;

            secret = HangmanSupport.GenerateSecret();
            letters = new char[MAX_ALPHABET_LETTERS];
            mask = new char[secret.Length];
            Console.WriteLine("--HANGMAN--");
            Console.WriteLine();
            Console.WriteLine();

            Console.WriteLine("Wins: {0}", winCount);
            Console.WriteLine("Losses: {0}", lossCount);
            Console.WriteLine("----------");
            Console.WriteLine();

            HangmanSupport.DisplayHangman(misses);
            Console.WriteLine();
            PrepareMaskAndLetters(mask, letters);

            DisplayMaskAndLetters(mask, letters);

            guess = GetGuess(secret.Length);
            match = CheckGuess(secret, mask, letters, guess);

            if (match == false)
            {
                while (misses < 6 || match != true)
                {
                    HangmanSupport.DisplayHangman(misses);
                    Console.WriteLine();
                    DisplayMaskAndLetters(mask, letters);

                    guess = GetGuess(secret.Length);
                    match = CheckGuess(secret, mask, letters, guess);

                    misses++;
                }               
            }
            else
            {

            }
            
        }
        /// <summary>
        /// returns guess made by user. guess must be 1 character long or must match the length of secret word.
        /// </summary>
        /// <param name="secretLength"> length of secret word</param>
        /// <returns>Valid guess</returns>
        static string GetGuess(int secretLength)
        {
            string guess;

            do
            {
                Console.Write("Enter guess (guess must be a single character or match the length of secret word): ");
                guess = Console.ReadLine();
            } while (guess.Length != secretLength && guess.Length != 1);

            return guess;
        }

        static void PrepareMaskAndLetters(char[] mask, char[] letters)
        {
            int count = 0;
            for (int idx = 0; idx < mask.Length; idx++)
            {
                mask[idx] = '_';
            }
            for (char alphabet = 'a'; alphabet <= 'z'; alphabet++)
            {
                letters[count] = alphabet;
                count++;
            }
        }
        static void DisplayMaskAndLetters(char[] mask, char[] letters)
        {
            int count = 0;

            Console.Write("Secret: ");
            for (int idx = 0; idx < mask.Length; idx++)
            {
                Console.Write("{0} ", mask[idx]);
            }

            Console.WriteLine();
            Console.WriteLine();

            Console.Write("Letters: ");
            for (char alphabet = 'a'; alphabet <= 'z'; alphabet++)
            {
                Console.Write("{0} ", letters[count]);
                count++;
            }
            Console.WriteLine();
        }
        static bool CheckGuess(char[] secret, char[] mask, char[] letters, string guess)
        {
            bool answer = false;

            if (guess.Length <= 1)
            {
                for (int idx = 0; idx < secret.Length; idx++)
                {
                    if (secret[idx] == guess[0])
                    {
                        answer = true;
                        mask[idx] = guess[0];

                        for (int i = 0; i < letters.Length; i++)
                        {
                            if (letters[i] == guess[0])
                            {
                                letters[i] = '_';
                            }
                        }
                    }
                }
            }
            else
            {
                for (int count = 0; count < guess.Length; count++)
                {
                    for (int idx = 0; idx < secret.Length; idx++)
                    {
                        if (guess[count] == secret[idx])
                        {
                            answer = true;
                            mask[idx] = guess[count];
                            for (int i = 0; i < letters.Length; i++)
                            {
                                if (letters[i] == guess[i])
                                {
                                    letters[i] = '_';
                                }
                            }

                        }
                    }
                }
            }
            return answer;
        }
    }
}
